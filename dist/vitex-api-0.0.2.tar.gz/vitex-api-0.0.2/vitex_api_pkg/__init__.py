# in __init__.py
from .vitex_api import VitexRestApi
from .vitex_api import VitexWebSocket